var f=n=>FToS(100-n*100/Object.values(users).length);
var sort_list=[
  ["avg_enemy_score_fixed","#EF"],
  ["global_avg_enemy_score","#G"],
  //["fixed-global","#F-G"],
  //["AS-EF","#AS-EF"],
  //["AS-EF","#(AS-EF)",(u,id)=>1+id],
];
var field="#S";var need_reverse=true;

var out=Object.values(users).map(u=>({
  "#AS":0,
  "#S":u.totalscore,
  //"TS":u.totalscore,
  user:u.user,
  avg_score:u.avg_score,
  //avg_enemy_score:u.avg_enemy_score,
  //"#E":0,
  avg_enemy_score_fixed:u.avg_enemy_score_fixed,
  "#EF":0,
  global_avg_enemy_score:u.global_avg_enemy_score,
  "#G":0,
  //"fixed-global":u.avg_enemy_score_fixed-u.global_avg_enemy_score,
  //"#F-G":0,
  //"AS-EF":u.avg_score-u.avg_enemy_score_fixed,
  //"#AS-EF":0,
})).sort((a,b)=>b.avg_score-a.avg_score).map((u,id)=>{u["#AS"]=1+id;return u;});
sort_list.map(e=>out.sort((a,b)=>b[e[0]]-a[e[0]]).map((u,id)=>{u[e[1]]=e.length>2?id+1:f(id);return u;}));
   /* 
    //sort((a,b)=>b.avg_enemy_score-a.avg_enemy_score).map((u,id)=>{u["#E"]=f(id);return u;}).
    sort((a,b)=>b.avg_enemy_score_fixed-a.avg_enemy_score_fixed).map((u,id)=>{u["#EF"]=f(id);return u;}).
    sort((a,b)=>b.global_avg_enemy_score-a.global_avg_enemy_score).map((u,id)=>{u["#G"]=f(id);return u;}).
    sort((a,b)=>b["fixed-global"]-a["fixed-global"]).map((u,id)=>{u["#F-G"]=f(id);return u;}).
    sort((a,b)=>b["AS/EF"]-a["AS/EF"]).map((u,id)=>{u["#AS/EF"]=f(id);return u;}).
   */ 
out=out.
    sort((a,b)=>b["#S"]-a["#S"]).map((u,id)=>{u["#S"]=1+id;return u;}).
    sort((a,b)=>b[field]-a[field]);

//out=qapfilter(out,"score");

out=need_reverse?out.reverse():out;
document.body.innerHTML="<pre>"+PrintMyTable(out);

var out=Object.values(users.alex_sh.maps).map(m=>mapdrop(m,["smart_d","smart_d_fixed","global_d","avg_enemy_score"]));
document.body.innerHTML="<pre>"+PrintMyTable(qapsort(out,e=>e.avg_enemy_score_fixed));

//document.body.innerHTML="<pre>"+PrintMyTable(Object.values(users.Adler.maps).map(m=>mapdrop(m,["smart_d","smart_d_fixed","global_d","avg_enemy_score"])));

var onMap=map=>{
  var allowed="Impuls,alladdin,	MagAlex,reat,Sirius,MrPingvi,Oxidize,KRB,wertrix,Spumote,Adler,dobord,DVS,santa324,Mr.Smile,ud1,spartan,FDoKE,ruspartisan,Ixanezis,jetblack,planB,tyamgin,GreenTea,alberist,AudiTT".split(",");
  var out=mapvals(users).map(u=>{var out=mapdrop(u.maps[map],["map","smart_d","smart_d_fixed","global_d","avg_enemy_score"],{user:u.user,guas:FToS(u.avg_score)});return out;});
  out=qapsort(out,e=>e.avg_enemy_score_fixed).map((e,id)=>mapaddfront(e,{"#EF":id+1}));
  out=qapsort(out,e=>e.score).map((e,id)=>mapaddfront(e,{N:id+1}));

  //out=qapsort(out,e=>e.avg_enemy_score_fixed).map((e,id)=>(e["#EF"]=id+1,e));
  var head_table=out.filter(e=>allowed.indexOf(e.user)>=0);
  //out=qapfilter(out,"score",e=>allowed.indexOf(e.user)>=0);
  byid("out").innerHTML="map: "+map+"\n"+PrintMyTable(head_table)+"\n<hr>\n"+PrintMyTable(out);
};

//
document.body.innerHTML="<hr><pre id='top'></pre><pre id='out'></pre>";
byid("top").innerHTML=mapkeys(maps).map(e=>"<button onclick='onMap("+json(e)+")'>"+e+"</button>").join(" ");

var out=[];
mapvals(users).map(u=>mapvals(u.maps).map(m=>{out.push({user:u.user,map:m.map,EF:m.avg_enemy_score_fixed,avg_score:m.avg_score});}));
var out=qapsort(out,e=>e.EF).map((e,id)=>mapaddfront(e,{"#":id+1}));
out=qapfilter(out,"avg_score",e=>allowed.indexOf(e.user)>=0);
document.body.innerHTML="<pre>"+PrintMyTable(out);

//gu2info[game_id][3]
var gu2info=garr.map(g=>g[2].map(u=>mapdrop(
  mapaddfront({cur_enemy:qapavg(games[g[1]][2].filter(e=>e!=u),e=>users[e].maps[g[0]].avg_score)},mapclone(users[u].maps[g[0]])),
  ["d","smart_d","smart_d_fixed","global_d","avg_enemy_score"],
  {game:g[1],user:u}
)));

// game_id to full info
var id=garr.reduce((pv,e,i)=>e[1]===196015?i:pv,-1);document.body.innerHTML="<pre>"+PrintMyTable(gu2info[id])+"\n"+JSON.stringify(garr[id])+"\n"+qapavg(gu2info[id],e=>e.avg_score);

// genereate 17mb html table with all games and players
var out=[];gu2info.map(e=>e.map(e=>{out.push(e)}));out=qapsort(out,e=>e.cur_enemy);document.body.innerHTML="<pre>"+PrintMyTable(out);

//
var gameswith=(a,b)=>garr.filter(g=>g[2].indexOf(a)>=0&&g[2].indexOf(b)>=0);//.map(g=>[g[0],g[1]]);
var a="Adler";var b="DVS";
document.body.innerHTML="<pre>games with '"+a+"' and '"+b+"'\n"+PrintMyTable(gameswith(a,b));

// enemy list
var enemy_map_for=user=>{
  var out={};garr.map(g=>{if(g[2].indexOf(user)>=0)g[2].map(u=>inc(out,u))});return mapsort(out);
};
document.body.innerHTML="<pre>"+map2str(enemy_map_for("Adler"));

// enemy_map_lengths table
var out=mapvals(users).map(u=>[u.user,mapvals(enemy_map_for(u.user)).length]);
document.body.innerHTML="<pre>"+map2str(qapsort(out,e=>e[1]))

// table with top game by avg_score
document.body.innerHTML="<pre>"+arr2str(qapsort(gu2info.map(g=>({game:g[0].game,map:g[0].map,avg_score:qapavg(g,e=>e.avg_score)})),e=>e.avg_score))