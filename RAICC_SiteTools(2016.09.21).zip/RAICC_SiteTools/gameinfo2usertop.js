var scan_param=(bef,s,aft)=>s.split(bef)[1].split(aft)[0];
var stat2obj=s=>({ec:-1,
  tc:parseFloat(scan_param("time consumed:",s,"of")),
  tp:parseFloat(scan_param("time passed:",s,"sec")),
  pm:parseFloat(scan_param("peak memory:",s,"bytes"))}
);
var conv_e9i=e9i=>{
  if(typeof (e9i)!=="string")return e9i;
  //if(e9i==="")return 
  if(e9i.indexOf("Time limit exceeded")>=0)return stat2obj(e9i);
  return e9i;
}
garr.map(e=>e[9]=e[9].map(conv_e9i));
var the_map="map10";var out=[];garr.map(e=>e[2].map((u,i)=>out.push({//(u==="mr.newman"?out:[]).push({
  map:e[0],
  id:e[1],
  user:u,
  v:e[3][i],
  pnts:e[4][0][i]|0,
  d:e[5][i],
  r:e[7],
  t:e[8],
  //log:json(e[9])
  ec:e[9][i].ec,
  tc:e[9][i].tc,
  tp:e[9][i].tp,
  pm:e[9][i].pm,//,e9i:json(e[9][i])//typeof (e[9][i]),
})));//document.body.innerHTML="<pre>"+PrintMyTable(out);
out=out.filter(e=>typeof e.tc!=="undefined");
var u2si={};var mu2si={};out.map(e=>(add(u2si,e.user,e),add(getobj(mu2si,e.map),e.user,e)));
//for(var m in mu2si)
var qapavgobj=arr=>{
  var obj=mapclone(arr[0]);
  for(var k in obj){var v=obj[k];if(typeof v==="number")obj[k]=FToS(qapavg(arr,e=>e[k]));}
  obj.games=arr.length;
  return obj;
};
out=mapvals(u2si).map(qapavgobj).map(e=>mapdrop(e,["v","id","ec","map"]));//.map((e,id)=>mapaddfront(e,{"#":id+1}));
out.map(e=>e.tpdtc=e.tp/e.tc);
out=qapsort(out,e=>e.tpdtc).map((e,id)=>mapaddfront(e,{"#":id+1}));
out=qapfilter(out,"d",()=>false);
document.body.innerHTML="<pre>"+PrintMyTable(out);