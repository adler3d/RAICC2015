var out="["+POST['data'].split("\n{\n").join(",\n{\n").split("\n}").join("\n},")+"]";//return out;
var map2str=m=>{var a=[];for(var k in m){a.push(k+":"+JSON.stringify(m[k]));};return "{\n"+a.join(",\n")+"\n}";}
var arr2str=out=>"[\n"+out.map(e=>JSON.stringify(e)).join(",\n")+"\n]";
var z=0;eval("z="+out);
z=z.filter(e=>typeof e!="number");
var out={};for(var i in z){var q=z[i];for(var k in q)out[k]=q[k];}
return map2str(out);