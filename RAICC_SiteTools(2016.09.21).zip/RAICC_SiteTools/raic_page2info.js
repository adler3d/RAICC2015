//xhr("get","http://russianaicup.ru/contest/3/games/page/800",(data,status)=>{document.body.innerHTML="<pre>"+status+"</pre>\n"+data;});
function xhr(method,url,callback)
{
  var x=new XMLHttpRequest();
  x.onreadystatechange=function(){if(x.readyState===4){callback(x.responseText,x.status,url);}};
  x.open(method,url);x.send();return x;
}
function tag(e,s){return Array.from(e.getElementsByTagName(s));}
var arr2str=out=>"[\n"+out.map(e=>JSON.stringify(e)).join(",\n")+"\n]";
var repelem=(elem,t,to)=>tag(elem,t).map(e=>e.outerHTML=to);
var games={};var g_run=1;var g_requests=0;var g_auto_add=0;var last_news=1;var gnews=0;var g_fails=[];
var page2info=(page)=>xhr('get',page,function(data,status,url){
  if(status!=200){g_fails.push([url,status,data]);console.log("fail at "+url);return;}
  var p=new DOMParser;
  var q=p.parseFromString(data,"text/html");
  var trs=q.getElementsByClassName("gamesTable")[0].getElementsByTagName("tbody")[0].getElementsByTagName("tr");
  last_news=0;
  function f(e){
    var map=0;tag(e,"img").forEach(elem=>{var tmp=elem.title.split(" ");if(tmp[0]=="�����")map=tmp[1];});
    var names=[];
    tag(e,"span").forEach(u=>{if(u.className!="day")names.push(u.innerHTML);});
    var v=[];var points=[];var d=[];var id=-1;var token=0;
    if(1)tag(e,"td").forEach((td,i)=>{
      if(0==i)id=tag(td,"a").map(e=>e.innerHTML|0)[0];
      if(5==i){tag(td,"hr").map(hr=>hr.outerHTML="\1");v=td.innerHTML.split("\1").map(i=>i|0);}
      if(6==i)points.push(tag(td,"div").map(
        div=>div.innerHTML
      ));
      if(8==i){repelem(td,"hr","\1");repelem(td,"img","");d=td.innerHTML.split("&nbsp;").join("").split("\1").map(i=>i|0);}
      if(9==i)token=tag(td,"div").map(e=>e.getAttribute("data-token"))[0];
      //i==6; �����
      //i==7; �����
      //i==9; ������� "�������� ����"
    });
    gnews++;
    if(!(id in games))last_news++;
    games[id]=[map,id,names,v,points,d,token];
    return [map,id,names,v,points,d,token];
  }
  var out=Array.from(trs).map(f);
  if(g_auto_add)document.body.innerHTML+="<pre>"+arr2str(out)+"</pre>";
  g_requests--;
});
document.body.innerHTML="";
//page2info("http://russianaicup.ru/contest/2/games/page/1");
//for(var i=1;i<10;i++)page2info("http://russianaicup.ru/contest/2/games/page/"+i);
var g_page=1;var g_request_limit=10;
window.setInterval(()=>{
  if(!g_run)return;
  if(g_requests>=g_request_limit)return;
  if(!last_news){console.log("end: "+g_page);g_run=0;return;}
  page2info("http://russianaicup.ru/contest/2/games/page/"+g_page);g_page++;g_requests++;
  if(g_page%100==0)console.log(g_page);
},128);
//g_fails.map(e=>{page2info(e[0]);g_requests++;});
//window.localStorage["games.r2"]=JSON.stringify(games);