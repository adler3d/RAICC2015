var bef=games_r1.length;//return games_r1.split(",")[0];
var maps={};var users={};
garr.map(g=>{inc(maps,g[0]);g[2].map(u=>inc(users,u));});
var u2v={};garr.map(g=>g[3].map((e,i)=>inc(getobj(u2v,g[2][i]),e)));for(var u in u2v){u2v[u]=[mapkeys(u2v[u]).map(e=>e|0),u];}
return arr2str(qapsort(mapvals(u2v).filter(e=>mapkeys(e[0]).length==2).map(e=>[e[0][1]-e[0][0],e[1]]),e=>e[0]));

var ump=JSON.parse(games_r1);u2id={};mapkeys(users).map((u,i)=>u2id[u]=i);m2id={};mapkeys(maps).map((u,i)=>m2id[u]=i);
ump.map(g=>{g[2]=g[2].map(u=>u2id[u]);g[4]=g[4][0].map(e=>e|0);g[0]=m2id[g[0]];g[5]=g[5].join("");if(g[5]==="8421")g[5]=0;});
return "[\n"+[arr2str(ump),json(mapkeys(maps)),json(mapkeys(users))].join(",\n")+"\n]";

//users who change version during round. and distance between version numbers.
return arr2str(qapsort(mapvals(u2v).filter(e=>mapkeys(e[0]).length==2).map(e=>[e[0][1]-e[0][0],e[1]]),e=>e[0]));