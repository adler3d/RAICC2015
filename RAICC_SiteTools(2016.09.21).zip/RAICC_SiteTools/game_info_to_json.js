var round_id=1;var rounds={1:{games:"games.r1",n:900,enemy_per_game:3},2:{games:"games.r2",n:360,enemy_per_game:3}};
var garr=JSON.parse(window.localStorage.getItem(rounds[round_id].games));
//if(undefined in games)delete games.undefined;
var games=(()=>{var games={};for(var i in garr){var g=garr[i];games[g[1]]=g;};return games;})();
//
function xhr(method,url,callback)
{
  var x=new XMLHttpRequest();
  x.onreadystatechange=function(){if(x.readyState===4){callback(x.responseText,x.status,url);}};
  x.open(method,url);x.send();return x;
}
function tag(e,s){return Array.from(e.getElementsByTagName(s));}
var arr2str=out=>"[\n"+out.map(e=>JSON.stringify(e)).join(",\n")+"\n]";
var map2str=m=>{var a=[];for(var k in m){a.push(k+":"+JSON.stringify(m[k]));};return "{\n"+a.join(",\n")+"\n}";}
var repelem=(elem,t,to)=>tag(elem,t).map(e=>e.outerHTML=to);
var gameid2info={};var g_run=1;var g_requests=0;var g_auto_add=0;var g_fails=[];
var game2info=(page)=>xhr('get',page,function(data,status,url){
  g_requests--;
  if(status!=200){g_fails.push([url,status,data]);console.log("fail at "+url);return;}
  var p=new DOMParser;
  var q=p.parseFromString(data,"text/html");
  scan_param=(bef,s,aft)=>s.split(bef)[1].split(aft)[0];
  byclass=c=>q.getElementsByClassName(c);
  var out=[
    byclass("gameContest")[0].innerHTML.trim(),
    byclass("gameCreationTime")[0].innerHTML.split("<br>").map(e=>e.trim()).join(" "),
    /*
    ����� runner&#39;� � stdout:
    Program successfully terminated
      exit code:    0
      time consumed: 2.78 sec
      time passed:  53.81 sec
      peak memory:  4706304 bytes
    */
    Array.from(byclass("strategy-protocol")).map(e=>e.attributes["strategy-protocol-text"].value).map(s=>(s.indexOf("exit code")<0?s:{
      ec:scan_param("exit code:",s,"\n")|0,
      tc:parseFloat(scan_param("time consumed:",s,"sec")),
      tp:parseFloat(scan_param("time passed:",s,"sec")),
      pm:parseFloat(scan_param("peak memory:",s,"bytes"))}
  ))];
  gameid2info[byclass("grayLight")[0].innerHTML.slice(1)]=out;
  if(g_auto_add)document.body.innerHTML+="<pre>"+arr2str(out)+"</pre>";
});
document.body.innerHTML="<button onclick='g_run=!g_run;console.log(g_run);'>stop</button>";
//game2info("http://russianaicup.ru/game/view/229477");

var g_page=25065;var g_request_limit=32;
window.setInterval(()=>{
  if(!g_run)return;
  if(g_requests>=g_request_limit)return;
  if(g_page>=garr.length){console.log("g_page>=garr.length = "+g_page>=garr.length);console.log("new end: "+g_page);g_run=0;return;}
  game2info("http://russianaicup.ru/game/view/"+garr[g_page][1]);g_page++;g_requests++;
  if(g_page%100==0)console.log(g_page+"/"+garr.length);
},16);
//g_fails.map(e=>{game2info(e[0]);g_requests++;});
//window.localStorage["gameid2info.r1"]=JSON.stringify(gameid2info);
//document.body.innerHTML="<pre>"+g_page+"\n"+map2str(gameid2info);
//var tak=[];garr.map(e=>{if(e[1] in gameid2info){}else{tak.push(e[1]);}});tak;tak.map(id=>game2info("http://russianaicup.ru/game/view/"+id));