//http://russianaicup.ru/game/view/231110
//http://russianaicup.ru/s/1455027419026/assets/jsrenderer/gameplayer.html?token=c2_oishgv5ydd2lb
var json=obj=>JSON.stringify(obj);
var FToS=n=>(n+0).toFixed(2);
var byid=id=>document.getElementById(id);
var qapavg=(arr,cb)=>{if(typeof cb=='undefined')cb=e=>e;return arr.length?arr.reduce((pv,ex)=>pv+cb(ex),0)/arr.length:0;}
var qapsum=(arr,cb)=>{if(typeof cb=='undefined')cb=e=>e;return arr.reduce((pv,ex)=>pv+cb(ex),0);}
var qapsort=(arr,cb)=>{if(typeof cb=='undefined')cb=e=>e;return arr.sort((a,b)=>cb(b)-cb(a));}
var mapdrop=(e,arr,n)=>{var out=n||{};Object.keys(e).map(k=>arr.indexOf(k)<0?out[k]=e[k]:0);return out;}
var mapsort=(arr,cb)=>{if(typeof cb=='undefined')cb=(k,v)=>v;var out={};var tmp=qapsort(mapkeys(arr),k=>cb(k,arr[k]));for(var k in tmp)out[tmp[k]]=arr[tmp[k]];return out;}
//var mapaddback=(obj,n)=>{for(var k in n)obj[k]=n[k];return obj;}
var mapaddfront=(obj,n)=>{for(var k in obj)n[k]=obj[k];return n;}
var mapclone=obj=>mapaddfront(obj,{});
var mapvals=m=>Object.values(m);
var mapkeys=m=>Object.keys(m);
var qapfilter=(out,param,cb)=>{
  if(typeof cb=='undefined')cb=e=>true;
  var top=out[0][param];return out.filter(e=>(e[param]>=top?(top=e[param],true):cb(e)));
}
function inc(map,key){if(!(key in map)){map[key]=0;}map[key]++;}
function add(map,key,v){if(!(key in map)){map[key]=[];}map[key].push(v);}
function getobj(map,key){if(!(key in map)){map[key]={};}return map[key];}
var arr2str=out=>"[\n"+out.map(e=>JSON.stringify(e)).join(",\n")+"\n]";
var map2str=m=>{var a=[];for(var k in m){a.push(k+":"+JSON.stringify(m[k]));};return "{\n"+a.join(",\n")+"\n}";}
var target_user="Hardept";var concrete_map=1?"map11":"";
var round_id=1;var rounds={1:{games:"games.r1",n:900,enemy_per_game:3},2:{games:"games.r2",n:360,enemy_per_game:3}};
var garr=JSON.parse(window.localStorage.getItem(rounds[round_id].games));
//if(undefined in games)delete games.undefined;
var games=(()=>{var games={};for(var i in garr){var g=garr[i];games[g[1]]=g;};return games;})();
var out=[];var maps={};
var users={};var fixed_d_in=[];var d_fail=0;
for(var id in games){var ex=games[id];maps[ex[0]]=[];}
for(var id in games){
  //  ["default",188012,["longloaf","Hohol","Stef","Shmaiser"],[61,25,21,10],[["2763","2356","2230","2064"]],[8,4,2,1],"c2_lbx2fmifzkmr86zjld1jandv3yl"]
  //  [   0     ,  1   ,                   2                  ,      3      ,               4               ,    5    ,                 6              ]
  //  [   map   ,  id  ,                  names               ,      v      ,             points            ,    d    ,                token           ]
  //if(games[id][2].indexOf("Adler")>=0)out.push(games[id]);
  //if(games[id][5][2]!=2&&games[id][5][1]!=3&&games[id][5][1]!=4)out.push(games[id]);
  //inc(dcounter,JSON.stringify(games[id][5]));
  var ex=games[id];
  if(!ex[5][0]){
    ex[5]=[8,4,2,1];
    var p=ex[4];
    if(p[0]==p[1]||p[1]==p[2]||p[2]==p[3])d_fail++;
    fixed_d_in.push(ex);
  }
  maps[ex[0]].push(ex);
  ex[2].map((e,i)=>{var u=getobj(users,e);add(getobj(u,"map2gameid"),ex[0],id);});
  ex[2].map((e,i)=>{var u=getobj(users,e);add(getobj(getobj(u,"v"),ex[3][i]),ex[0],id);});
}
var make_top=arr=>{
  arr.sort((a,b)=>a[2][0]>b[2][0]);
  return arr;
};
for(var k in users)
{
  var u=users[k];u.user=k;u.maps={};u.totalscore=0;u.avg_scores=[];
  for(var map in u.map2gameid)
  {
    var usergames=u.map2gameid[map].map(id=>games[id]);
    var m=getobj(u.maps,map);
    m.map=map;
    m.d=usergames.map(ex=>{var id=ex[2].indexOf(k);return id>=0?ex[5][id]:0;});
    m.score=qapsum(m.d);
    m.dn=m.d.filter(e=>e!=0).length;
    m.avg_score=m.score/m.dn;
    u.avg_scores.push(m.avg_score);
    u.totalscore+=m.score;
  }
  u.avg_score=qapavg(u.avg_scores);
}
for(var k in users)
{
  var u=users[k];u.avg_enemy_score=[];u.avg_enemy_score_fixed=[];u.global_avg_enemy_score=[];
  for(var map in u.maps)
  {
    var m=u.maps[map];
    var usergames=u.map2gameid[map].map(id=>games[id]);
    //enemy_avg_d_on_this_map
    m.smart_d=usergames.map(ex=>{
      var id=ex[2].indexOf(k);
      var a=ex[2].map(e=>(users[e].maps[map].avg_score*(e!=k?1:0)));
      return [a,qapavg(a.filter(e=>e!==0))];
    });
    m.smart_d_fixed=usergames.map(ex=>{
      var id=ex[2].indexOf(k);
      var a=ex[2].map(e=>{
        if(e==k)return 0;
        var eu=users[e];
        var em=eu.maps[map];
        var eg=eu.map2gameid[map].map(id=>games[id]);
        var emd=eg.map(ex=>{var id=ex[2].indexOf(e);if(ex[2].indexOf(k)>=0)return 0;return id>=0?ex[5][id]:0;});
        return qapavg(emd.filter(e=>e!==0));
      });
      return [a,qapavg(a.filter(e=>e!==0))];
    });
    m.global_d=usergames.map(ex=>{
      var id=ex[2].indexOf(k);
      var a=ex[2].map(e=>(users[e].avg_score*(e!=k?1:0)));
      return [a,qapavg(a.filter(e=>e!==0))];
    });
    //m.en=m.smart_d.reduce((pv,ex)=>pv+(ex[1]>0?1:0),0)*rounds[round_id].enemy_per_game;
    m.avg_enemy_score=qapavg(m.smart_d,ex=>ex[1]);
    m.avg_enemy_score_fixed=qapavg(m.smart_d_fixed,ex=>ex[1]);
    m.global_avg_enemy_score=qapavg(m.global_d,ex=>ex[1]);
    u.avg_enemy_score.push(m.avg_enemy_score);
    u.avg_enemy_score_fixed.push(m.avg_enemy_score_fixed);
    u.global_avg_enemy_score.push(m.global_avg_enemy_score);
  }
  u.avg_enemy_score=qapavg(u.avg_enemy_score);
  u.avg_enemy_score_fixed=qapavg(u.avg_enemy_score_fixed);
  u.global_avg_enemy_score=qapavg(u.global_avg_enemy_score);
}
for(var k in users)
{
  var u=users[k];u.map2enemy_score={};
  for(var map in u.maps)
  {
    var m=u.maps[map];
    var info={
      map:map,
      avg_d:FToS(m.avg_score),
      avg_ed:FToS(m.avg_enemy_score),
      avg_ed_fixed:FToS(m.avg_enemy_score_fixed),
      "[C2-C3]":FToS(m.avg_enemy_score-m.avg_enemy_score_fixed),
      "5*(C2-C3)/n":FToS((m.avg_enemy_score-m.avg_enemy_score_fixed)*5/m.smart_d.length),
      g_avg_ed:FToS(m.global_avg_enemy_score),
      smart_d:json(m.smart_d.map(e=>[e[0].map(FToS),FToS(e[1])])).split("\"").join("")
    };
    u.map2enemy_score[map]=info;
  }
}
var user_maps_enemy_score=Object.values(users["Adler"].map2enemy_score);
var sort_field="5*(C2-C3)/n";
user_maps_enemy_score.sort((a,b)=>b[sort_field]-a[sort_field]);
document.body.innerHTML="<pre>"+PrintMyTable(user_maps_enemy_score);
document.body.innerHTML="<pre>"+arr2str(user_maps_enemy_score);
var games2coderwithgames=(map,arr)=>{
  var out=[];
  for(var k in users){
    var u=users[k];
    var m=u.maps[map];
    out.push([m.d,m.score,k]);
    //var usergames=u.map2gameid[map].map(id=>games[id]);var json=a=>a;
    //out.push([
    //  json(usergames.reduce((pv,ex)=>{var id=ex[2].indexOf(k);pv.push(id>=0?ex[5][id]:0);return pv;},[])),
    //  usergames.reduce((pv,ex)=>{var id=ex[2].indexOf(k);pv+=(id>=0?ex[5][id]:0);return pv;},0),
    //  k
    //]);
  }
  //arr.map(e=>add(coders,e[2][0],e));
  //var q=Object.values(coders);
  //q.sort((a,b)=>b.length-a.length);
  //var tmp=[rounds[round_id].n];q.map(e=>inc(tmp,e.length)+(tmp[0]--));return tmp;
  //return q.map(e=>e[0][2][0]+" = "+e.length);
  /*var out=q.map(e=>{var user=e[0][2][0];return [
    json(garr.reduce((pv,ex)=>{if(ex[0]!=map)return pv;var id=ex[2].indexOf(user);if(id>=0)pv.push(id>=0?ex[5][id]:0);return pv;},[])),
    garr.reduce((pv,ex)=>{if(ex[0]!=map)return pv;var id=ex[2].indexOf(user);if(id>=0)pv+=(id>=0?ex[5][id]:0);return pv;},0),
    user
  ];});*/
  out.sort((a,b)=>b[1]-a[1]);
  if(!concrete_map)return out.reduce((pv,e,i)=>{return e[2]!=target_user?pv:[e,1+i]},target_user+" - not found");
  return out;
};
var single_push=1;var joinarr=arr=>arr;//[].concat.apply([],arr);
for(var k in maps){
  if(concrete_map)k=concrete_map;
  var m=maps[k];
  var sortedtop=m=>joinarr(games2coderwithgames(k,m));
  document.body.innerHTML="<pre>top_for_"+k+":"+map2str(sortedtop(m));
  if(concrete_map)break;
  
  out.push([sortedtop(m),k]);single_push=0;
}
if(!single_push)document.body.innerHTML="<pre>"+arr2str(out);